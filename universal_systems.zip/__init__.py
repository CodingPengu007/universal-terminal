"""
This package contains various systems and programs for universal applications.
"""

# You can import modules or classes that you want to expose at the package level.
# For example:
from .programs import *
from .system_programs import *